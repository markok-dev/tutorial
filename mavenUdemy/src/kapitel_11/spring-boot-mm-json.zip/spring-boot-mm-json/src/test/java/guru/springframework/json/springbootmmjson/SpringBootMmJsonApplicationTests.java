package guru.springframework.json.springbootmmjson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMmJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
