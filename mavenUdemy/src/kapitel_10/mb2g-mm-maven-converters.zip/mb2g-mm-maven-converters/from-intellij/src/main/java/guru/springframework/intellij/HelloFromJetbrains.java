package guru.springframework.intellij;

/**
 * Created by jt on 2018-12-15.
 */
public class HelloFromJetbrains {

    public String sayHello(){
        return "Hello from JetBrains!";
    }
}
